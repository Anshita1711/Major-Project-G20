import mongoose from 'mongoose';
import * as dotenv from 'dotenv';

dotenv.config();

async function connectdb() {
  try {
    await mongoose.connect(process.env.MONGO_CONNECTION_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Database connected 👍');
  } catch (error) {
    console.error('Connection failed 👎', error.message);
    process.exit(1); // Exit the process on failure
  }
}

export default connectdb;
