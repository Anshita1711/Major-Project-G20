# ALUM Connect

A portal for connecting alumni and students, sharing news, updates, job and referral opportunities, and building a strong student network. ALUM Connect enables users to search alumni, view referral feeds, and stay updated with the latest notifications.

Visit the app: [ALUM Connect Live](https://uietconnect.onrender.com/)

---

## :sparkles: Features

- **Alumni Search:** Find alumni by name, batch, branch, and more.
- **Referral Feeds:** View and create posts about jobs, internships, and referrals.
- **Profile Management:** Update your profile, education, and experience.
- **Notifications:** Stay updated with the latest opportunities and announcements.
- **Authentication:** Secure login and registration with JWT and password hashing.
- **Rich Text Editor:** Create posts using Quill editor.

---

## :wrench: Tech Stack

- Node.js, Express.js
- MongoDB, Mongoose
- EJS templating
- JavaScript, CSS (custom + Bootstrap)
- Quill Editor
- JWT, bcrypt
- dotenv

---

## :rocket: Getting Started

### 1. Clone the Repository

```bash
git clone https://github.com/getlost01/connectuiet.git
cd connectuiet
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Configure Environment

Create a `.env` file in the root directory and add your MongoDB connection string and secret:

```
MONGO_CONNECTION_URL=your_mongodb_connection_url
SECRET=your_secret_key
```

### 4. Start the Development Server

```bash
npm start
```
or with nodemon:
```bash
npm test
```

The app will run on [http://localhost:3000](http://localhost:3000).

---

## :mag: Preview

![Dashboard Preview](https://github.com/getlost01/connectuiet/assets/79409258/631a7fc2-d5b5-415a-81a2-f10b6b063ec0)
![Feed Preview](https://github.com/getlost01/connectuiet/assets/79409258/3ab808cb-affb-493b-b234-cdfeeb01b48c)
![Profile Preview](https://github.com/getlost01/connectuiet/assets/79409258/86ed6eca-7f3e-491a-8e3f-2de2c3e4ad36)

---

## :v: Contributing

1. Fork the repository and clone it locally.
2. Create a new branch for your feature or bugfix.
3. Push your changes and open a pull request.

---

## :file_folder: Project Structure

```
.
├── app.js
├── package.json
├── .env
├── APIs/
│   └── alumniDetail.js
├── config/
│   └── db.js
├── middlewares/
│   └── auth.js
├── models/
│   ├── alumni.js
│   └── post.js
├── public/
│   ├── css/
│   ├── images/
│   └── js/
├── routes/
│   └── pages.js
├── views/
│   ├── home.ejs
│   ├── form.ejs
│   ├── profile.ejs
│   ├── post.ejs
│   ├── search.ejs
│   ├── settings.ejs
│   ├── error.ejs
│   └── unauth.ejs
└── ...
```

---

## :lock: License

This project is licensed under the ISC License.

---

<p align="center">
Give the project a ⭐ if you liked it.<br>
Made with ❤️ and Node.js.
</p>